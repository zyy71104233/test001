//package com.example.aiarchdesigner.config;
//
//import org.springframework.ai.chat.client.ChatClient;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//   public class AiConfig {
//
//       @Bean
//       public ChatClient chatClient() {
//           // 根据实际需求初始化，例如使用 OpenAI 或本地模型
//           return ChatClient. // 示例地址
//                            .build();
//       }
//   }
//