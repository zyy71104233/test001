package com.example.aiarchdesigner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiArchDesignerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AiArchDesignerApplication.class, args);
    }

} 